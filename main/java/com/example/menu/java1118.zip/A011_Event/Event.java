package com.example.menu.A011_Event;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.fragment.app.FragmentActivity;

import com.example.menu.A07_RestaurantDetail.RestaurantDetailView;
import com.example.menu.R;

import org.angmarch.views.NiceSpinner;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Event extends FragmentActivity {

    ListView list;
    EventList adapter;
    String[] name,reply;

    int[] image,images;

    private ImageButton back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a11_event);

        NiceSpinner niceSpinner = (NiceSpinner) findViewById(R.id.spinner_user);
        List<String> dataset = new LinkedList<>(Arrays.asList("可參加", "未回覆", "不克出席"));
        niceSpinner.attachDataSource(dataset);


        name = new String[]{ "Spicy Fried Rice &amp; Bacon Amet", "Shrimp Curry Burger Ipsam dolor Sit", "Masala Spiced Chickpeas Dolor Amet", "Kung Pao Pastrami ad Minima Sit", "Chicken Doro Wat Nisi Commodo Amet","Mango Cile Chutney Et Dolore Sit"};

        image = new int[] { R.drawable.listimg1,R.drawable.listimg2,
                R.drawable.listimg3,R.drawable.listimg4,
                R.drawable.listimg5,R.drawable.listimg6};

        reply = new String[]{"不克參加", "暫不回覆", "可以參加", "不克參加", "可以參加", "不克參加"};

        images = new int[] { R.drawable.pic2,R.drawable.pic3,
                R.drawable.pic4};

//      回去Notifiction
        back = (ImageButton) findViewById(R.id.back_arrow);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Event.this.finish();
            }
        });


//      呼叫list
        list = (ListView) findViewById(R.id.mylist);

        // Pass results to ListViewAdapter Class
        adapter = new EventList(this, name,reply, image);
        // Binds the Adapter to the ListView
        list.setAdapter(adapter);
        // Capture ListView item click
////        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
////
////            @Override
////            public void onItemClick(AdapterView<?> parent, View view,
////                                    int position, long id) {
////
////                Toast.makeText(Event.this,"You have selected :"+name[position], Toast.LENGTH_SHORT).show();
////
////
//            }
//
//        });

    }

    public void DetailLink(View v) {
        Intent browserIntent = new Intent(getApplicationContext(), RestaurantDetailView.class);
        startActivity(browserIntent);
    }

}