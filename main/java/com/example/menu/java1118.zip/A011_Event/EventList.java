package com.example.menu.A011_Event;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.menu.R;
import com.mikhaellopez.circularimageview.CircularImageView;


public class EventList extends BaseAdapter{
    // Declare Variables
    Context context;
    String[] name,reply;
    int[] images;
    LayoutInflater inflater;

    public EventList(Context context, String[] name,String[] reply,int[] images) {
        this.context = context;
        this.name = name;
        this.reply = reply;
        this.images = images;
    }

    @Override
    public int getCount() {
        return name.length;
    }


    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        // Declare Variables
        TextView txtname,textreply;
        CircularImageView imagename;

        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(R.layout.a11_event_list, parent, false);

        // Locate the TextViews in listview_item.xml
        txtname = (TextView) itemView.findViewById(R.id.title_content);

        textreply = (TextView) itemView.findViewById(R.id.reply_content);

        // Locate the ImageView in listview_item.xml
        imagename = (CircularImageView) itemView.findViewById(R.id.image_data);

        // Capture position and set to the TextViews
        txtname.setText(name[position]);

        textreply.setText(reply[position]);


        // Capture position and set to the ImageView
        imagename.setImageResource(images[position]);

        return itemView;
    }
}

//public class RestaurantDetailListview2 extends BaseAdapter {
//

//}
//
