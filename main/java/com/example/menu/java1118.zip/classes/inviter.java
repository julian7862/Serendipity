package com.example.menu.classes;

public class inviter {
    private String inviter_uid;

    public inviter() {
    }

    public inviter(String inviter_uid) {
        this.inviter_uid = inviter_uid;
    }

    public String getInviter_uid() {
        return inviter_uid;
    }

    public void setInviter_uid(String inviter_uid) {
        this.inviter_uid = inviter_uid;
    }
}
