package com.example.menu.SendNotificationPack;

public class MyResponse {
    public int success;

}
