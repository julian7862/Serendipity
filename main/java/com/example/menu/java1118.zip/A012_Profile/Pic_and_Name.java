package com.example.menu.A012_Profile;

public class Pic_and_Name {

    String Img,Name;

    public String getImg() {
        return Img;
    }

    public void setImg(String img) {
        Img = img;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

}
